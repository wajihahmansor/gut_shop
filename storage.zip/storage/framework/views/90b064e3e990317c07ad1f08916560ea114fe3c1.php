<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <?php if(Session::has('success_msg')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
        <?php endif; ?>
    <!-- Posts list -->
    <?php if(!empty($posts)): ?>
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Posts List </h2>
                </div>
                <div class="pull-right">
                    <a class="btn btn-success" href="<?php echo e(route('posts.add')); ?>"> Add New</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <table class="table table-striped task-table">
                    <!-- Table Headings -->
                    <thead>
                        <th width="25%">Title</th>
                        <th width="40%">Content</th>
                        <th width="15%">Created</th>
                        <th width="20%">Action</th>
                    </thead>
    
                    <!-- Table Body -->
                    <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="table-text">
                                <div><?php echo e($post->title); ?></div>
                            </td>
                            <td class="table-text">
                                <div><?php echo e($post->content); ?></div>
                            </td>
                                <td class="table-text">
                                <div><?php echo e($post->created); ?></div>
                            </td>
                            <td>
                                <a href="<?php echo e(route('posts.details', $post->id)); ?>" class="label label-success">Details</a>
                                <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="label label-warning">Edit</a>
                                <a href="<?php echo e(route('posts.delete', $post->id)); ?>" class="label label-danger" onclick="return confirm('Are you sure to delete?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>